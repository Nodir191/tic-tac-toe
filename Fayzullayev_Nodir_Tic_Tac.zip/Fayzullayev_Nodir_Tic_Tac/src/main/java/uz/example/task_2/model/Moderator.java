package uz.example.task_2.model;

import java.util.ArrayList;
import java.util.List;

public class Moderator {
    private List<Book> borrowedBooks;

    public Moderator() {
        this.borrowedBooks = new ArrayList<>();
    }

    public void addBook(String title, String author) {
        Book newBook = new Book(title, author);
        borrowedBooks.add(newBook);
        System.out.println("New book added: " + newBook);
    }

    public void searchBooks(String title, String author) {
        System.out.println("Searching for books with title: " + title + ", author: " + author);
        for (Book book : borrowedBooks) {
            if (book.getTitle().equalsIgnoreCase(title) && book.getAuthor().equalsIgnoreCase(author)) {
                System.out.println("Found book: " + book);
            }
        }
    }

    public void returnBook(User user, int shelfIndex, int bookIndex) {
        Shelf shelf = LibraryManager.getInstance().getRack(shelfIndex).getShelf(1);
        Book returnedBook = shelf.takeBook(bookIndex);
        borrowedBooks.remove(returnedBook);
        System.out.println("Book returned by user " + user.getEmail() + ": " + returnedBook);
    }
    public void displayBorrowedBooks() {
        System.out.println("Borrowed Books:");
        for (Book book : borrowedBooks) {
            System.out.println(book);
        }
    }
}
