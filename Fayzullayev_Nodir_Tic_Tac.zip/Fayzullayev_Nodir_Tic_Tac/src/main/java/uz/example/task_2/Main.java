package uz.example.task_2;

import uz.example.task_2.model.*;

import java.util.Scanner;

//Fayzullayev Nodir
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int userType;
        do {
                System.out.println("Choose user type:");
                System.out.println("1. User");
                System.out.println("2. Moderator");
                System.out.println("3. Admin");
                System.out.println("0. Exit");
                System.out.print("Choose user type: ");
                userType = scanner.nextInt();

                switch (userType) {
                    case 1:
                        userMenu();
                        break;
                    case 2:
                        moderatorMenu();
                        break;
                    case 3:
                        adminMenu();
                        break;
                    case 0:
                        System.out.println("Exiting the program.");
                        break;
                    default:
                        System.out.println("Invalid option! Please choose again.");
                }
            } while (userType != 0) ;

    }

    private static void userMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your email: ");
        String userEmail = scanner.next();
        User user = new User(userEmail);

        if (!user.isRegistered()) {
            System.out.println("User not registered. Registering now...");
            user.register();
        }

        int userOption;
        do {
            System.out.println("User Menu:");
            System.out.println("1. Search for Books");
            System.out.println("2. Borrow a Book");
            System.out.println("3. Return a Book");
            System.out.println("0. Exit");
            System.out.print("Choose option: ");
            userOption = scanner.nextInt();

            switch (userOption) {
                case 1:
                    searchBooks();
                    break;
                case 2:
                    borrowBook(user);
                    break;
                case 3:
                    returnBook(user);
                    break;
                case 0:
                    System.out.println("Exiting user menu.");
                    break;
                default:
                    System.out.println("Invalid option! Please choose again.");
            }
        } while (userOption != 0);
    }

    private static void moderatorMenu() {
        Moderator moderator = new Moderator();
        Scanner scanner = new Scanner(System.in);

        int moderatorOption;
        do {
            System.out.println("Moderator Menu:");
            System.out.println("1. Add a Book");
            System.out.println("2. Search for Books");
            System.out.println("3. Return a Book");
            System.out.println("4. Display Borrowed Books");
            System.out.println("0. Exit");
            System.out.print("Choose option: ");
            moderatorOption = scanner.nextInt();

            switch (moderatorOption) {
                case 1:
                    System.out.print("Enter the title of the book: ");
                    String bookTitle = scanner.next();
                    System.out.print("Enter the author of the book: ");
                    String bookAuthor = scanner.next();
                    moderator.addBook(bookTitle, bookAuthor);
                    break;
                case 2:
                    searchBooks();
                    break;
                case 3:
                    returnBook(null);
                    break;
                case 4:
                    moderator.displayBorrowedBooks();
                    break;
                case 0:
                    System.out.println("Exiting moderator menu.");
                    break;
                default:
                    System.out.println("Invalid option! Please choose again.");
            }
        } while (moderatorOption != 0);
    }

    private static void adminMenu() {
        Admin admin = new Admin();
        admin.manageLibrary();
    }

    private static void searchBooks() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the title of the book: ");
        String bookTitle = scanner.next();
        System.out.print("Enter the author of the book: ");
        String bookAuthor = scanner.next();

        LibraryManager.getInstance().searchBooks(bookTitle, bookAuthor);
    }

    private static void borrowBook(User user) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the shelf index: ");
        int shelfIndex = scanner.nextInt();
        System.out.print("Enter the book index: ");
        int bookIndex = scanner.nextInt();

        Shelf shelf = LibraryManager.getInstance().getRack(1).getShelf(shelfIndex);
        Book borrowedBook = shelf.takeBook(bookIndex);
        ((Book) borrowedBook).reserve();
        System.out.println("Book borrowed by user " + user.getEmail() + ": " + borrowedBook);
    }

    private static void returnBook(User user) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the shelf index: ");
        int shelfIndex = scanner.nextInt();
        System.out.print("Enter the book index: ");
        int bookIndex = scanner.nextInt();

        Shelf shelf = LibraryManager.getInstance().getRack(1).getShelf(shelfIndex);
        Book returnedBook = shelf.takeBook(bookIndex);
        returnedBook.unreserve();
        System.out.println("Book returned by user " + user.getEmail() + ": " + returnedBook);
    }
}
