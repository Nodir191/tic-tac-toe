package uz.example.task_2.model;

public class User {
    private String email;
    private boolean isRegistered;

    public User(String email) {
        this.email = email;
        this.isRegistered = false;
    }

    public String getEmail() {
        return email;
    }

    public boolean isRegistered() {
        return isRegistered;
    }

    public void register() {
        isRegistered = true;
        System.out.println("User with email " + email + " is now registered.");
    }

    @Override
    public String toString() {
        return "User: " + email;
    }
}
