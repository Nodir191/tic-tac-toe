package uz.example.task_2.model;

import java.util.Scanner;

public class Admin {
    public void manageLibrary() {
        LibraryManager manager = LibraryManager.getInstance();
        Scanner scanner = new Scanner(System.in);

        int option;
        do {
            System.out.println("Admin Menu:");
            System.out.println("1. Add Rack");
            System.out.println("2. Remove Rack");
            System.out.println("3. Display Library");
            System.out.println("0. Exit");
            System.out.print("Choose option: ");
            option = scanner.nextInt();

            switch (option) {
                case 1:
                    manager.addRack();
                    System.out.println("Rack added successfully.");
                    break;
                case 2:
                    System.out.print("Enter the index of the rack to remove: ");
                    int rackIndexToRemove = scanner.nextInt();
                    manager.removeRack(rackIndexToRemove);
                    System.out.println("Rack removed successfully.");
                    break;
                case 3:
                    displayLibraryStatus();
                    break;
                case 0:
                    System.out.println("Exiting admin menu.");
                    break;
                default:
                    System.out.println("Invalid option! Please choose again.");
            }
        } while (option != 0);
    }

    private void displayLibraryStatus() {
        LibraryManager manager = LibraryManager.getInstance();
        System.out.println("Library Status:");
        for (int i = 1; i <= manager.getRackCount(); i++) {
            Rack rack = manager.getRack(i);
            System.out.println(rack);
            for (int j = 1; j <= 10; j++) {
                Shelf shelf = rack.getShelf(j);
                System.out.println("  " + shelf);
                for (int k = 1; k <= 10; k++) {
                    Book book = shelf.takeBook(k);
                    System.out.println("    " + book);
                }
            }
        }
    }
}