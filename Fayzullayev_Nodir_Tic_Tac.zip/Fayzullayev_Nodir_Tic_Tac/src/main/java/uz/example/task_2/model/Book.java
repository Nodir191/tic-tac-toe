package uz.example.task_2.model;

public class Book {
    private String title;
    private String author;
    private boolean isReserved;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isReserved = false;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isReserved() {
        return isReserved;
    }

    public void reserve() {
        isReserved = true;
    }

    public void unreserve() {
        isReserved = false;
    }

    @Override
    public String toString() {
        return title + " - " + author + " (Reserved: " + isReserved + ")";
    }
}
