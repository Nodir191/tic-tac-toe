package uz.example.task_2.model;

class Library {
    private Rack[] racks;

    public Library() {
        this.racks = new Rack[4];
        initializeLibrary();
    }

    private void initializeLibrary() {
        for (int i = 0; i < racks.length; i++) {
            racks[i] = new Rack(i + 1);
        }
    }

    public void addRack() {
        Rack[] newRacks = new Rack[racks.length + 1];
        System.arraycopy(racks, 0, newRacks, 0, racks.length);
        newRacks[newRacks.length - 1] = new Rack(newRacks.length);
        racks = newRacks;
    }

    public void removeRack(int rackIndex) {
        Rack[] newRacks = new Rack[racks.length - 1];
        System.arraycopy(racks, 0, newRacks, 0, rackIndex - 1);
        System.arraycopy(racks, rackIndex, newRacks, rackIndex - 1, racks.length - rackIndex);
        racks = newRacks;
    }
    public void searchBooks(String title, String author) {
        System.out.println("Searching for books with title: " + title + ", author: " + author);
        for (Rack rack : racks) {
            for (Shelf shelf : rack.getShelves()) {
                for (Book book : shelf.getBooks()) {
                    if (book.getTitle().equalsIgnoreCase(title) && book.getAuthor().equalsIgnoreCase(author)) {
                        System.out.println("Found book: " + book);
                    }
                }
            }
        }
    }
    public Rack getRack(int rackIndex) {
        return racks[rackIndex - 1];
    }
    public int getRackCount() {
        return racks.length;
    }
    @Override
    public String toString() {
        return "Library";
    }
}