package uz.example.task_2.model;

import java.util.ArrayList;
import java.util.List;

public class Shelf {
    private int shelfId;
    private List<Book> books;

    public Shelf(int shelfId) {
        this.shelfId = shelfId;
        this.books = new ArrayList<>();
        initializeShelf();
    }

    private void initializeShelf() {
        for (int i = 0; i < 10; i++) {
            books.add(new Book("Empty", "Empty"));
        }
    }

    public List<Book> getBooks() {
        return books;
    }

    public void placeBook(int bookIndex, Book book) {
        books.set(bookIndex - 1, book);
    }

    public Book takeBook(int bookIndex) {
        Book takenBook = books.get(bookIndex - 1);
        books.set(bookIndex - 1, new Book("Empty", "Empty"));
        return takenBook;
    }

    @Override
    public String toString() {
        return "Shelf #" + shelfId;
    }
}