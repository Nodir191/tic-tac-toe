package uz.example.task_2.model;

import java.util.ArrayList;
import java.util.List;

public class Rack {
    private int rackId;
    private List<Shelf> shelves;

    public Rack(int rackId) {
        this.rackId = rackId;
        this.shelves = new ArrayList<>();
        initializeRack();
    }

    private void initializeRack() {
        for (int i = 0; i < 20; i++) {
            shelves.add(new Shelf(i + 1));
        }
    }

    public List<Shelf> getShelves() {
        return shelves;
    }

    public Shelf getShelf(int shelfIndex) {
        return shelves.get(shelfIndex - 1);
    }
    public void addShelf() {
        shelves.add(new Shelf(shelves.size() + 1));
    }

    public void removeShelf(int shelfIndex) {
        if (shelfIndex > 0 && shelfIndex <= shelves.size()) {
            shelves.remove(shelfIndex - 1);
        } else {
            System.out.println("Invalid shelf index.");
        }
    }

    @Override
    public String toString() {
        return "Rack #" + rackId;
    }
}