package uz.example.task_1;
import java.util.Random;
import java.util.Scanner;
//Fayzullayev Nodir
public class Main {
    private static char[][] board = {
            {' ', ' ', ' '},
            {' ', ' ', ' '},
            {' ', ' ', ' '}
    };
    private static char currentPlayer = 'X';
    private static Scanner scanner = new Scanner(System.in);
    private static Random random = new Random();

    public static void main(String[] args) {
        int option;
        do {
            System.out.println("Tic Tac Toe Game");
            System.out.println("1. Play with a Friend");
            System.out.println("2. Play with the Computer");
            System.out.println("0. Exit");
            System.out.print("Choose: ");
            option = scanner.nextInt();

            switch (option) {
                case 1:
                    playWithFriend();
                    break;
                case 2:
                    playWithComputer();
                    break;
                case 0:
                    System.out.println("Game over!");
                    break;
                default:
                    System.out.println("Invalid choice! Please choose again.");
            }
        } while (option != 0);
    }

    private static void printBoard() {
        System.out.println("-------------");
        for (char[] row : board) {
            System.out.print("| ");
            for (char cell : row) {
                System.out.print(cell + " | ");
            }
            System.out.println();
            System.out.println("-------------");
        }
    }

    private static void playWithFriend() {
        int row, col;
        boolean validMove;
        do {
            printBoard();
            System.out.println("Player " + currentPlayer + ", enter your move (row and column): ");
            row = getUserInput("Row: ");
            col = getUserInput("Column: ");
            validMove = makeMove(row, col);
            if (!validMove) {
                System.out.println("Invalid move! Try again.");
            }
        } while (!isBoardFull() && !checkWinner());

        printResult();
    }

    private static void playWithComputer() {
        int row, col;
        boolean validMove;
        do {
            printBoard();
            if (currentPlayer == 'X') {
                System.out.println("Player X, enter your move (row and column): ");
                row = getUserInput("Row: ");
                col = getUserInput("Column: ");
                validMove = makeMove(row, col);
            } else {
                System.out.println("Computer's turn (Player O): ");
                int[] computerMove = getComputerMove();
                row = computerMove[0];
                col = computerMove[1];
                validMove = makeMove(row, col);
            }
            if (!validMove) {
                System.out.println("Invalid move! Try again.");
            }
        } while (!isBoardFull() && !checkWinner());

        printResult();
    }

    private static int getUserInput(String message) {
        System.out.print(message);
        return scanner.nextInt() - 1;
    }

    private static boolean makeMove(int row, int col) {
        if (row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == ' ') {
            board[row][col] = currentPlayer;
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            return true;
        }
        return false;
    }

    private static int[] getComputerMove() {
        int row, col;
        do {
            row = random.nextInt(3);
            col = random.nextInt(3);
        } while (board[row][col] != ' ');
        return new int[]{row, col};
    }

    private static boolean isBoardFull() {
        for (char[] row : board) {
            for (char cell : row) {
                if (cell == ' ') {
                    return false;
                }
            }
        }
        return true;
    }

    private static boolean checkWinner() {
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == currentPlayer && board[i][1] == currentPlayer && board[i][2] == currentPlayer) {
                return true;
            }
            if (board[0][i] == currentPlayer && board[1][i] == currentPlayer && board[2][i] == currentPlayer) {
                return true;
            }
        }
        if (board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer) {
            return true;
        }
        return board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer;
    }

    private static void printResult() {
        printBoard();
        if (checkWinner()) {
            System.out.println("Player " + currentPlayer + " wins!");
        } else {
            System.out.println("The game is a draw! No one wins.");
        }
    }
}
