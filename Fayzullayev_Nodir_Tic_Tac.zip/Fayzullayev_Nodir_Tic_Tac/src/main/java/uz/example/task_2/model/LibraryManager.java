package uz.example.task_2.model;

public class LibraryManager {
    private static LibraryManager instance;
    private Library library;

    private LibraryManager() {
        this.library = new Library();
    }

    public static LibraryManager getInstance() {
        if (instance == null) {
            instance = new LibraryManager();
        }
        return instance;
    }

    public void addRack() {
        library.addRack();
    }

    public void removeRack(int rackIndex) {
        library.removeRack(rackIndex);
    }

    public Rack getRack(int rackIndex) {
        return library.getRack(rackIndex);
    }

    public int getRackCount() {
        return library.getRackCount();
    }
    public void searchBooks(String title, String author) {
        library.searchBooks(title, author);
    }
}